//
//  ViewController.m
//  RadioStations
//
//  Created by Strider on 9/17/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import "ViewController.h"
#import "RadioStation.h"

@implementation ViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    myStation = [[RadioStation alloc] initWithName:@"STAR 94" 
                                       atFrequency:94.1];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)buttonClick:(id)sender {
    [stationName setText:[myStation name]];
    [stationFrequency setText:[NSString stringWithFormat:@"%.1f",
                               [myStation frequency]]];
    
    if (([myStation frequency] >= [RadioStation minFMFrequency]) &&
        ([myStation frequency] <= [RadioStation maxFMFrequency])) {
        [stationBand setText:@"FM"];
    } else {         
        [stationBand setText:@"AM"];
    }
}

@end
