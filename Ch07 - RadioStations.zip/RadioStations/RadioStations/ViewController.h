//
//  ViewController.h
//  RadioStations
//
//  Created by Strider on 9/17/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RadioStation;

@interface ViewController : UIViewController
{
    RadioStation *myStation;
    IBOutlet UILabel *stationName;
    IBOutlet UILabel *stationFrequency;
    IBOutlet UILabel *stationBand;
}

- (IBAction)buttonClick:(id)sender;

@end
