//
//  RadioStation.h
//  RadioStations
//
//  Created by Strider on 9/17/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface RadioStation : NSObject
{
    NSString  *name;
    double     frequency;
    NSUInteger band;
}

+ (double)minAMFrequency;
+ (double)maxAMFrequency;
+ (double)minFMFrequency;
+ (double)maxFMFrequency;


- (id)initWithName:(NSString *)newName
       atFrequency:(double)newFrequency;
- (NSString *)name;
- (void)setName:(NSString *)newName;
- (double)frequency;
- (void)setFrequency:(double)newFrequency;

@end
