//
//  ViewController.h
//  MyFirstApp
//
//  Created by Strider on 9/5/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    IBOutlet UILabel *nameLabel;
}

- (IBAction)showName:(id)sender;

@end
