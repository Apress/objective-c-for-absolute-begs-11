//
//  AppDelegate.h
//  MyFirstApp
//
//  Created by Strider on 9/5/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
