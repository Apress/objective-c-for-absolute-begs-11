//
//  BookStoreTests.h
//  BookStoreTests
//
//  Created by Brad Lees on 10/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface BookStoreTests : SenTestCase

@end
