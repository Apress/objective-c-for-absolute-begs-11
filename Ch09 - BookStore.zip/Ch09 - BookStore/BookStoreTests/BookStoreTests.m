//
//  BookStoreTests.m
//  BookStoreTests
//
//  Created by Brad Lees on 10/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "BookStoreTests.h"

@implementation BookStoreTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in BookStoreTests");
}

@end
