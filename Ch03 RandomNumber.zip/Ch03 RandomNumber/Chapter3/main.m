//
//  main.m
//  Chapter3
//



#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        int firstNumber = 2;
        int secondNumber = 3;
        int totalSum = 0;
        firstNumber = firstNumber + 1;
        secondNumber = secondNumber + 1;
        totalSum = firstNumber + secondNumber;
        NSLog(@"%d",totalSum);
        
        NSLog(@"The program has terminated successfully.");
        
        
    }
    return 0;
}

