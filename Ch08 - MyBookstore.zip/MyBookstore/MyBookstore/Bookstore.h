//
//  Bookstore.h
//  MyBookstore
//
//  Created by Strider on 8/28/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Book.h"

@interface Bookstore : NSObject

@property(strong, nonatomic) NSMutableArray *theBookStore;

- (NSUInteger)count;
- (Book *)bookAtIndex:(NSUInteger)index;

@end
