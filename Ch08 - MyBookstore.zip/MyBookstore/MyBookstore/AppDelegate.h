//
//  AppDelegate.h
//  MyBookstore
//
//  Created by Strider on 8/28/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController *navigationController;

@end
