//
//  Book.m
//  MyBookstore
//
//  Created by Strider on 8/28/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import "Book.h"

@implementation Book

@synthesize title, author, description;

@end
