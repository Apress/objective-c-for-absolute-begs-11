//
//  MasterViewController.h
//  MyBookstore
//
//  Created by Strider on 8/28/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;
@class Bookstore;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;
@property (strong, nonatomic) Bookstore *myBookStore;

@end
