//
//  DetailViewController.h
//  MyBookstore
//
//  Created by Strider on 8/28/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (strong, nonatomic) id detailItem;

@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UILabel *authorLabel;
@property (strong, nonatomic) IBOutlet UITextView *descriptionTextView;
@end
