//
//  Bookstore.m
//  MyBookstore
//
//  Created by Strider on 8/28/11.
//  Copyright (c) 2011 www.committed-code.com. All rights reserved.
//

#import "Bookstore.h"

@implementation Bookstore

@synthesize theBookStore;

- (id)init
{
    self = [super init];
    if (self) {
        self.theBookStore = [[NSMutableArray alloc] init];
        Book *newBook = [[Book alloc] init];        
        newBook.title = @"Objective-C for Absolute Beginners";
        newBook.author = @"Bennett, Fisher and Lees";
        newBook.description = @"iOS Programming made easy.";
        [self.theBookStore addObject:newBook];
        
        newBook = [[Book alloc] init];
        newBook.title = @"A Farewell To Arms";
        newBook.author = @"Ernest Hemingway";
        newBook.description = @"The story of an affair between an English "
                               "nurse and an American soldier "
                               "on the Italian front "
                               "during World War I.";
        [self.theBookStore addObject:newBook];
        newBook = nil;
    }
    
    return self;
}

- (NSUInteger)count
{
    return [self.theBookStore count];
}

- (Book *)bookAtIndex:(NSUInteger)index
{
    return [self.theBookStore objectAtIndex:index];
}

@end
