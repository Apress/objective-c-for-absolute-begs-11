//
//  main.m
//  HelloWorld
//
//  Created by Gary Bennett on 5/10/11.
//  Copyright (c) 2011 xcelME. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"The Eagle has landed.");
        NSLog(@"That's one small step for man, one giant leap for mankind");
        
    }
    return 0;
}

