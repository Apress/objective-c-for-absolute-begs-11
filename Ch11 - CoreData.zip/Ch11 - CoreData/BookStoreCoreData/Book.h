//
//  Book.h
//  BookStoreCoreData
//
//  Created by Brad Lees on 6/14/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Book : NSManagedObject {
@private
}
@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) NSNumber * price;
@property (nonatomic, retain) NSNumber * yearPublished;
@property (nonatomic, retain) NSManagedObject * author;

@end
