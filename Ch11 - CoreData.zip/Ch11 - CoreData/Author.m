//
//  Author.m
//  BookStoreCoreData
//
//  Created by Brad Lees on 6/14/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Author.h"
#import "Book.h"


@implementation Author
@dynamic lastName;
@dynamic firstName;
@dynamic book;


@end
