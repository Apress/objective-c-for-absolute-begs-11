//
//  BookStoreCoreDataTests.h
//  BookStoreCoreDataTests
//
//  Created by Brad Lees on 6/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface BookStoreCoreDataTests : SenTestCase {
@private
    
}

@end
